import React, { useState } from 'react'
import axios from 'axios'
import ButtonAppBar from '../components/NavBar'
import { Container } from '@mui/material'
import ResponsiveAppBar from '../components/SearchBar'
import SearchAppBar from '../components/CitySearch'
import BasicCard from '../components/TodaysWeather'
import CurrentDateTime from '../components/CurrentDateTimeCard'
import Current_Temp_Card from '../components/CurrentTempCard'
import Current_Icon_Condition from '../components/CurrentIconConditionCard'



const Homepage = () => {
    const [searchValue, setSearchValue] = useState("")
    const [weatherData, setWeatherData] = useState("")
    const [locationData, setLocationData] = useState("")

    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(searchValue)
        axios.get(`http://api.weatherapi.com/v1/current.json?key=72733a4a54444b9d88c211620232903 &q=${searchValue}&aqi=no`)
            .then(res => {
                setWeatherData(res.data.current)
                setLocationData(res.data.location)
                console.log(weatherData)
            })
            .catch(err => {
                console.log("Error for API call", err)
            })
    }

    return (
        <div className='Homepage'>
            <h1>Enter a city or zip code </h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>City or Zip</label>
                    <input type="text" onChange={(e) => { setSearchValue(e.target.value) }} />
                </div>
                <div>
                    <button type='submit'>Search</button> |
                </div>
            </form>
            <div>
                <h3>{locationData.name}</h3>
                <h3>{weatherData.temp_f}</h3>
                <h3>{weatherData.feelslike_f}</h3>

            </div>
            <div>
                <ButtonAppBar />
                <form onSubmit={handleSubmit}>
                    <SearchAppBar />
                </form>
                <ResponsiveAppBar />
                <h1>Today's Weather in Chicago, Illinois</h1>
                <Container sx={{ marginY: 5, display: 'flex', justifyContent: 'center' }}>
                    <CurrentDateTime />
                    <Current_Temp_Card />
                    <Current_Icon_Condition />
                </Container>
            </div>
        </div>
    )
}


export default Homepage


